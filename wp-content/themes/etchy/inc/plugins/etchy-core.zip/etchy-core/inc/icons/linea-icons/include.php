<?php

include_once ETCHY_CORE_INC_PATH . '/icons/linea-icons/linea-icons.php';