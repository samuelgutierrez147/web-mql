<?php

include_once ETCHY_CORE_INC_PATH . '/icons/elegant-icons/elegant-icons.php';