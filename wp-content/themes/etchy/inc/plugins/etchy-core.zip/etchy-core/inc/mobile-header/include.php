<?php

include_once ETCHY_CORE_INC_PATH . '/mobile-header/helper.php';
include_once ETCHY_CORE_INC_PATH . '/mobile-header/mobile-header.php';
include_once ETCHY_CORE_INC_PATH . '/mobile-header/mobile-headers.php';
include_once ETCHY_CORE_INC_PATH . '/mobile-header/template-functions.php';