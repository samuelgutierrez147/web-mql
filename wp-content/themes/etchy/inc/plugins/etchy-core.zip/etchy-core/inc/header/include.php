<?php

include_once ETCHY_CORE_INC_PATH . '/header/helper.php';
include_once ETCHY_CORE_INC_PATH . '/header/header.php';
include_once ETCHY_CORE_INC_PATH . '/header/headers.php';
include_once ETCHY_CORE_INC_PATH . '/header/template-functions.php';