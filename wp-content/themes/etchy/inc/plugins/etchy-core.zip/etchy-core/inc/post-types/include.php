<?php

include_once ETCHY_CORE_CPT_PATH . '/post-types.php';