<?php

class QodeFrameworkOptionsFront extends QodeFrameworkOptions {

	public function __construct() {
		parent::__construct();
	}
}
